import { Component, OnInit, EventEmitter,
   Output, ViewChild, ElementRef } from '@angular/core';

@Component({
  selector: 'app-cockpet',
  templateUrl: './cockpet.component.html',
  styleUrls: ['./cockpet.component.css']
})
export class CockpetComponent implements OnInit {

  @Output('servCreated') serverCreated = new EventEmitter<{name:string,content:string}>();
  @Output('bpCreated') bluePrintCreate = new EventEmitter<{name:string,content:string}>();
  //newServerName = '';
  //newServerContent = '';
  @ViewChild('serverContentInput') serverContent: ElementRef;
  constructor() { }

  ngOnInit() {
  }
  onAddServer(nameInput: HTMLInputElement){
    this.serverCreated.emit({
      name: nameInput.value,
    content: this.serverContent.nativeElement.value
    });
    
  }
  onAddBluePrint(nameInput: HTMLInputElement){
      this.bluePrintCreate.emit({
        name: nameInput.value,
        content: this.serverContent.nativeElement.value
      }) 
  }

}
