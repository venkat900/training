import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  //styleUrls: ['./index.component.css']
  styles: [
    `.even {
         color: white;
    }
    `,
    `.odd {
      color: yellow;
 }
 `
]
})
export class IndexComponent implements OnInit {
   log = [];
   
  constructor() { }

  ngOnInit() {
  }

  onToggleDetails(){
    this.log.push(new Date());
  }

}
