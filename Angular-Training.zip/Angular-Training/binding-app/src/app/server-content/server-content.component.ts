import { Component, OnInit, Input, OnChanges, SimpleChanges, ViewChild, ElementRef, DoCheck, AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked, ContentChild } from '@angular/core';

@Component({
  selector: 'app-server-content',
  templateUrl: './server-content.component.html',
  styleUrls: ['./server-content.component.css']
})
export class ServerContentComponent implements OnInit,
                        OnChanges,DoCheck,
                        AfterContentInit,
                        AfterContentChecked,
                        AfterViewInit,
                        AfterViewChecked
                         {
   @Input('serverElement')
  element: {type:string,name:string,content:string};
  @Input() name: string;
  @ViewChild('heading') header: ElementRef;
  @ContentChild('paragraphContent') paragraph: ElementRef;

  constructor() {
    console.log('Constructor is called!')
   }
  ngOnChanges(changes: SimpleChanges){
   console.log('OnChanges is Called!');
   console.log('Changes: '+changes)
  }
  ngOnInit() {
    console.log('OnInit is Called!');
    console.log('Tex Content: '+this.header.nativeElement.textContent);
    console.log('Paragraph: '+this.paragraph.nativeElement.textContent);
  }
  ngDoCheck(){
    console.log('DoCheck is Called!');
  }
  ngAfterContentInit(){
    console.log('afterContentInit is Called!');
    console.log('Paragraph: '+this.paragraph.nativeElement.textContent);
  }
  ngAfterContentChecked(){
    console.log('AfterContentChecked is Called!');
  }
  ngAfterViewInit(){
    console.log('AfterViewInit is Called!');
  }
  ngAfterViewChecked(){
    console.log('AfterViewChecked is Called!');
  }
  ngOnDestroy(){
    console.log('onDestroy is Called!');
  }
}
