import { Injectable, EventEmitter } from '@angular/core';
import { stringify } from '@angular/compiler/src/util';
import { LoggingService } from './logging.service';

@Injectable({
  providedIn: 'root'
})
export class AccountService {
  accounts = [
    {name: 'Master Account', status: 'active'},
    {name: 'Test Account', status: 'inctive'},
    {name: 'Hidden Account', status: 'hidden'}
  ];
  statusUpdated = new EventEmitter<string>();

  constructor(private logService: LoggingService) { }
  
  addAccount(name: string, status: string){
    this.accounts.push({name:name,status:status});
    this.logService.logStatusChanged(status);
 }
 updateStatus(id:number,newStatus: string){
   this.accounts[id].status = newStatus;
   this.logService.logStatusChanged(newStatus);
 }
}
